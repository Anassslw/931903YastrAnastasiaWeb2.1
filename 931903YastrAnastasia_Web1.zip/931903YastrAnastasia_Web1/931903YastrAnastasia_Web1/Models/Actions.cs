﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _931903YastrAnastasia_Web1.Models
{
    public class Actions
    {
        public int val1 { get; set; }
        public int val2 { get; set; }
        public int div { get; set; }
        public int sub { get; set; }
        public int add { get; set; }
        public int mul { get; set; }
    }
}
